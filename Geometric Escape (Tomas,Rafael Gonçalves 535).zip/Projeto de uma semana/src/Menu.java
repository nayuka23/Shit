import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Frame;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Menu extends JFrame {

	private JPanel contentPane;
	private Frame frameLoader;
	
	public static int player=1;
	
	ImageIcon player1=new ImageIcon(Nivel2.class.getResource("player1.png"));
	ImageIcon player2=new ImageIcon(Nivel2.class.getResource("player2.png"));
	ImageIcon player3=new ImageIcon(Nivel2.class.getResource("player3.png"));
	ImageIcon player4=new ImageIcon(Nivel2.class.getResource("player4.png"));
	ImageIcon play=new ImageIcon(Nivel2.class.getResource("play.png"));
	private JPanel panel;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setUndecorated(true);
					//frame.setBackground(new Color(1.0f,1.0f,1.0f,0.5f));
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		
		
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1440, 900);
		contentPane = new JPanel();
		
		contentPane.setForeground(new Color(148, 0, 211));
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
	     
	     
		panel = new JPanel();
		panel.setBackground(Color.white);
		panel.setBounds(320, 0, 800, 900);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel icon3 = new JLabel(player3);
		icon3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				player=3;
			}
		});
		
		JLabel jogar = new JLabel("JOGAR");
		jogar.setBounds(250, 200, 272, 117);
		panel.add(jogar);
		jogar.setFont(new Font("Sitka Subheading", Font.PLAIN, 93));
		jogar.setForeground(Color.WHITE);
		
		JLabel start = new JLabel(play);
		start.setBounds(310, 400, 150, 150);
		panel.add(start);
		start.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Nivel1 lvl1 = new Nivel1();
				lvl1.setVisible(true);
			}
		});
		icon3.setBounds(450, 600, 90, 90);
		panel.add(icon3);
		
		JLabel icon4 = new JLabel(player4);
		icon4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				player=4;
			}
		});
		icon4.setBounds(250, 600, 90, 90);
		panel.add(icon4);
		
		JPanel panel_1 = new JPanel();
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Menu menu =new Menu();
				Nivel1 lvl1 = new Nivel1();
				menu.setVisible(false);
				lvl1.setVisible(true);
			}
		
		});
		panel_1.setBorder(new LineBorder(Color.CYAN, 3));
		panel_1.setBackground(Color.DARK_GRAY);
		panel_1.setBounds(0, 0, 800, 900);
		panel.add(panel_1);
		
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE) {
					System.exit(0);
				}
			}
		});
		
	}
}

